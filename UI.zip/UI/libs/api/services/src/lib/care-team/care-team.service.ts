import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { ICareTeamState } from 'app/features/care-team/state/care-team.reducer';
import { CLINICAL_API_URL } from '../common/api-url-tokens';

@Injectable({
    providedIn: 'root',
  })
export class CareTeamService {

    constructor(private http: HttpClient, @Inject(CLINICAL_API_URL) private clinicalApiUrl: string) {}

    public getPatientCareTeams(patientId) {
        return this.http.get<ICareTeamState>(`${this.clinicalApiUrl}/patients/${patientId}/patient-aggregate`);
    }
}