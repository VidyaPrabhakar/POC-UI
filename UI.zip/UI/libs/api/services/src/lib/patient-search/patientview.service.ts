import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { PatientSearchModel } from '@polaris/features/select-patient/models/patient-model';
import { PatientViewModelList } from 'app/features/select-patient/models/patientviewmodel';
import { AuthService } from 'app/auth/auth.service';
import { CLINICAL_API_URL } from '../common/api-url-tokens';


@Injectable({
    providedIn: 'root',
})
export class PatientViewService {
    constructor(private http: HttpClient, @Inject(CLINICAL_API_URL) private clinicalApiUrl: string) { }

    public getAllPatient(searchData: PatientSearchModel) {
        const url = `${this.clinicalApiUrl}/patients/patient-search?SearchText=` + searchData.searchText + `&SortOrder=` + searchData.sortOrder + `&AssignedProviderId=` + searchData.assignedProviderId;
        return this.http.get<PatientViewModelList>(url);
    }
}
    