import { CLINICAL_API_URL } from './api-url-tokens';


/**
 * CLINICAL API FACTORY INFORMATION
 */

export function clinicalApiUrlFactory() {
    return '/api/local/clinical';
}

export const CLINICAL_API = {
    provide: CLINICAL_API_URL,
    useFactory: clinicalApiUrlFactory,
};