import { InjectionToken } from '@angular/core';

export const CLINICAL_API_URL = new InjectionToken('Clinical API Url');
