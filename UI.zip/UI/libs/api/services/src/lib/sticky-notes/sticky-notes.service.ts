import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs';

import { IStickyNotesService } from '@polaris/api/interfaces';
import { PatientsService } from '@polaris/features/select-patient/patients.service';
import { PatientViewModel } from '@polaris/features/select-patient/models/patientviewmodel';
import { StickyNotesModel } from '@polaris/features/sticky-notes/sticky-notes.model';
import { CLINICAL_API_URL } from '../common/api-url-tokens';


@Injectable({
  providedIn: 'root',
})
export class StickyNoteService implements IStickyNotesService {
  constructor(private http: HttpClient,
    private patientService: PatientsService,
    @Inject(CLINICAL_API_URL) private clinicalApiUrl: string
    ) { }

    patients: PatientViewModel;
    //public apiPath = '/api/local/clinical/patients';

  public loadStickyNotes() {
    this.patientService.selectedpatient.subscribe((patient)=>{
      this.patients = patient;
    });
    return this.http.get<StickyNotesModel[]>(`${this.clinicalApiUrl}/patients/${this.patients.patientId}/sticky-notes`);
  }

  public updateStickyNotes(body: StickyNotesModel): Observable<any> {
    const headers = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json-patch+json'
      })
    }
    return this.http.put<StickyNotesModel>(`${this.clinicalApiUrl}/patients/${body.patientId}/sticky-notes/${body.noteSid}/edit`, JSON.stringify(body), headers);
  }

  public deleteStickyNotes(deletedNoteId, patientId) {
    const queryString = `${this.clinicalApiUrl}/patients/sticky-notes/${deletedNoteId}/delete/${patientId}`;
    return this.http.request<boolean>('delete', queryString);
  }

  public addStickyNotes(addStickyNote: StickyNotesModel): Observable<any> {
    const headers = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json-patch+json'
      })
    };
    return this.http.post<StickyNotesModel>(`${this.clinicalApiUrl}/patients/${addStickyNote.patientId}/sticky-notes/post`, addStickyNote, headers)
  }
}
