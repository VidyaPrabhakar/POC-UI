import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MessageDetails } from 'app/features/chatbot/message.model';
import { BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root',
})

export class ChatbotService {
    public selectedMessage = new BehaviorSubject<MessageDetails>(undefined);
    public selectedData: string;
    public isAppointmentChecked = false;
    public isSymptomChecked = false;
    constructor(private http: HttpClient
    ) { }
    public getChatbotAppointmentDetails(patientId: number, keyword:string, selectedData: string, recentQuestion: string,options: string) { 
        return this.http.get(`/api/local/chatbot/api/v1/resources/appointments?patientid=`+ patientId +`&id=`+keyword+`&selectedData=`+selectedData+`&recentQuestion=`+recentQuestion+`&options=`+options)
    }
    public getChatbotSymptomsDetails(patientId: number, keyword:string, selectedData: string, recentQuestion: string,options: string) { 
        return this.http.get(`/api/local/chatbot/api/v1/resources/symptoms?patientid=`+ patientId +`&id=`+keyword+`&selectedData=`+selectedData+`&recentQuestion=`+recentQuestion+`&options=`+options);
    }
    
}

