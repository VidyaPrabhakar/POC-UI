import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Inject, Injectable, InjectionToken } from '@angular/core';

import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

import { ICarePlan } from '@polaris/api/interfaces';
import { CLINICAL_API_URL } from '../common/api-url-tokens';
import { PatientCarePlan, CarePlanGoalRequest } from 'app/features/care-plan/models';

@Injectable({ providedIn: 'root' })
export class CarePlanService implements ICarePlan {
    private queryString;

    constructor(
        private http: HttpClient,
        @Inject(CLINICAL_API_URL) private clinicalApiUrl: string,
    ) { }

    public updateCarePlanGoal(carePlanGoalRequests: CarePlanGoalRequest) {
        if (!carePlanGoalRequests.patientId) {
            return throwError(
                new Error('Required parameter patientId was null or undefined when calling addUpdateCarePlanGoal.'),
            );
        }
        if (!carePlanGoalRequests.description) {
            return throwError(
                new Error('Required parameter description was null or undefined when calling addUpdateCarePlanGoal.'),
            );
        }
        return this.http
            .post(`${this.clinicalApiUrl}/patients/care-plan/save-patient-care-plan-goal`, carePlanGoalRequests)
            .pipe(catchError(this.handleError));
    }

    public addCarePlanGoal(carePlanGoalRequests: CarePlanGoalRequest) {
        const headers = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json-patch+json'
            })
        };
        return this.http.post(`${this.clinicalApiUrl}/patients/${carePlanGoalRequests.patientId}/care-plan/post`, carePlanGoalRequests, headers);
    }

    private handleError(response: HttpErrorResponse) {
        let errorMessage = '';
        if (response.error && response.error.errorMessage) {
            errorMessage = response.error.errorMessage;
        } else {
            errorMessage = response.message;
        }
        return throwError(new Error(errorMessage));
    }
}
