import { Observable } from 'rxjs';
import { CarePlanGoalRequest } from 'app/features/care-plan/models';


export interface ICarePlan {
   // getCarePlanGoals(patient: string): Observable<PatientCarePlan[]>;
    updateCarePlanGoal(updateCarePlanGoalRequests: CarePlanGoalRequest);
    addCarePlanGoal(updateCarePlanGoalRequests: CarePlanGoalRequest);   
}