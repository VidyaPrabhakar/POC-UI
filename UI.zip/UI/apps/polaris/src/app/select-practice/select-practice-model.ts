export class SelectPracticeModel {
  id: number;
  name: string;
}
