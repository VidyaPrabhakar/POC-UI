import { SelectPracticeModel } from './select-practice-model';

export const PRACTICES: SelectPracticeModel[] = [
  { id: 1, name: 'Madison Medical Center P. A.' },
  { id: 2, name: 'Alachua Community Health Center' },
  { id: 3, name: 'Spring Diagnostic Center' },
  { id: 4, name: 'Sage Specialty Clinic' },
]





