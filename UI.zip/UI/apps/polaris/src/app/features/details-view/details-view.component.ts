import { Component, Input, OnInit } from '@angular/core'
import { LastUserName, PatientCarePlan } from '../care-plan/models/care-plan.model';
import { PatientCareTeam, SpecialtyTypes, PhoneNumbers, Providers } from '../care-team/models/care-team.model';
import * as moment from 'moment';
import { DetailsViewModel } from './details-view.model';

@Component({
    selector: 'pol-new-details-view',
    templateUrl: './details-view.component.html',
    styleUrls: ['./details-view.component.scss']
})

export class DetailsViewComponent implements OnInit {
    @Input() public detailsViewModel: DetailsViewModel;
    public selectedId: string;
    public viewModel: any[] = [];
    public ngOnInit() {
        this.viewModelMapper();
    }
    private viewModelMapper() {
        this.viewModel = [];
        if(this.detailsViewModel && this.detailsViewModel.details){
            this.detailsViewModel.details.forEach((result) => {
                if (this.detailsViewModel.typeOf === "PatientCareTeam") {
                    this.viewModel.push({
                        details: result,
                        id: result.patientRefDocSpecialtySid,
                        description: this.getProviderName(result.refDoctorId),
                        subDescription: this.getSpecialty(result.specialtyCode.toString()),
                        additionDescription: this.getProviderPhone(result.refDoctorId),
                    });
                }else if (this.detailsViewModel.typeOf === "PatientCarePlan") {
                    this.viewModel.push({
                        details: result,
                        id: result.patientCareplanGoalSid,
                        description: result.description,
                        subDescription: "",
                        additionDescription: "",
                    });
                }
            });
        }
        
    }
    public getLastUserName(lastUserId: number) {
        const lastUserName = LastUserName.find(data => data.id === lastUserId).value;
        return lastUserName;
    }
    private getSpecialty(specialtyId) {
        const specialtyName = SpecialtyTypes.find(data => data.id === specialtyId).value;
        return specialtyName;
    }
    private getProviderName(providerId) {
        const provider = Providers.find(data => data.id === providerId).value
        return provider;
    }
    private getProviderPhone(providerId) {
        const phoneNumber = PhoneNumbers.find(data => data.id === providerId).value;
        return phoneNumber;
    }
    public itemClick(id:string)
    {
        this.selectedId = id;
    }
}
