export class DetailsViewModel {
    title: string;
    count: number;
    details: any[];
    isQueueOpen: boolean;
    typeOf: string;
}
