import { DetailsViewComponent } from './details-view.component';
import { cloneDeep } from 'lodash';
import { MockCareTeam } from '../care-team/mock-data/care-team-mock-data';

describe('DetailsViewComponent', () => {
    let comp: DetailsViewComponent;
    beforeEach(() => {
        comp = new DetailsViewComponent();
        comp.detailsViewModel = {
            count: 2,
            details: cloneDeep(MockCareTeam.patientCarePlan),
            isQueueOpen: true,
            title: 'Goals',
            typeOf: 'PatientCarePlan'
        }
    });

    describe('when initialized', () => {
        it('should have a defined component', () => {
            expect(comp).toBeDefined();
        });
    });

    describe('ngOnInit', () => {
        beforeEach(() => {
            comp.ngOnInit();
        });
        it('detailsViewModel should set values to the care plan', () => {
            expect(comp.detailsViewModel.details).toEqual(cloneDeep(MockCareTeam.patientCarePlan))
        });
        it('detailsViewModel count as 2', () => {
            expect(comp.detailsViewModel.count).toEqual(2);
        });
        it('detailsViewModel should set the length as 2', () => {
            expect(comp.detailsViewModel.details.length).toEqual(2);
        });
        it('viewModel should set the length as 2', () => {
            expect(comp.viewModel.length).toEqual(2);
        });
        it('viewModel should set values to the care plan', () => {
            expect(comp.viewModel[1].details).toEqual(cloneDeep(MockCareTeam.patientCarePlan[1]));
        });
    });

    describe('getLastUserName', () => {
        it('should return the last user name', () => {
            const lastUser = comp.getLastUserName(37);
            expect(lastUser).toEqual('David Ford MD');
        });
    });

   
});