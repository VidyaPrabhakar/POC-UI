import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from 'app/app-matierial.module';
import { FormsModule } from '@angular/forms';
import { DetailsViewComponent } from './details-view.component';
import { CardViewModule } from '../card-view/card-view.module';

@NgModule({
    imports: [CommonModule,  MaterialModule, FormsModule, CardViewModule],
    exports: [DetailsViewComponent],
    declarations: [DetailsViewComponent]
})
export class DetailsViewModule {}