import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PatientsService }  from '../patients.service';
import {MatBottomSheet} from '@angular/material/bottom-sheet';
import { ChatbotComponent } from 'app/features/chatbot/chatbot.component';
import { LiveChatDialogComponent } from 'app/features/live-chat/live-chat-dialog-component';
import { MatDialog } from '@angular/material/dialog';
import { PatientViewModel } from '../models/patientviewmodel';

@Component({
  selector: 'pol-new-patient-details',
  templateUrl: './patient-details.component.html',
  styleUrls: ['./patient-details.component.css']
})
export class PatientDetailsComponent{
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: PatientsService,
    private _bottomSheet: MatBottomSheet,
    private dialog: MatDialog,
  ) {}
  public openBottomSheet(): void {
    this._bottomSheet.open(ChatbotComponent);
    } 

    public onLiveChatClick() {
      const dialogRef = this.dialog.open(LiveChatDialogComponent, {
        height: '350px',
        width: '500px',
        position: {
          bottom: '1%',
          right: '1%',
        },
      });
    }
}
