export class PatientSearchModel{
    sortOrder: string;
    searchText: string;
    assignedProviderId: string;
}
