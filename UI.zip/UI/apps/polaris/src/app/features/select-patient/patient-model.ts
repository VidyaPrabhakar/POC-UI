export class PatientModel {
  id: number;
  name: string;
}
