import { Component } from '@angular/core';


@Component({
    selector: 'pol-new-sticky-notes',
    templateUrl: 'sticky-notes.component.html',
    styleUrls: ['./sticky-notes.component.css']
})
export class StickyNotesComponent {

    constructor() {}
    public notesCount: number;

    public stickyNotesCount(count) {
        this.notesCount = count;
    }
}
