import { Injectable, OnInit } from "@angular/core";
import { Store } from '@ngrx/store';
import { IStickyNotesState } from './sticky-notes.reducer';
import * as searchActions from './sticky-notes.actions';

export interface AppState {
    readonly stickyNotes: IStickyNotesState
  }

@Injectable()
export class StickyNotesFacade {
    constructor(private store: Store<AppState>) { }

    public readonly notesView = this.store.select(store => store.stickyNotes);

    public addNotes(note) {
        this.store.dispatch(new searchActions.StickyNotesAddAction(note));
    }

    public editNote(editedNote) {
        this.store.dispatch(new searchActions.StickyNotesEditAction(editedNote));
    }

    public deleteNote(noteSid, patientId) {
        this.store.dispatch(new searchActions.StickyNotesDeleteAction(noteSid, patientId));
    }
}