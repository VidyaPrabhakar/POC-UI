import { Actions, Effect, ofType } from '@ngrx/effects';
import { Injectable } from '@angular/core';
import {
    StickyNotesActionTypes,
    StickyNotesLoadAction,
    StickyNotesLoadSuccessAction,
    StickyNotesAddAction,
    StickyNotesEditAction,
    StickyNotesDeleteAction,
} from './sticky-notes.actions';
import { switchMap, map, mergeMap } from 'rxjs/operators';
import { StickyNoteService } from '@polaris/api/services';
import { CareTeamsLoadAction } from 'app/features/care-team/state/care-team.actions';

@Injectable()
export class StickyNotesEffects {
    constructor(protected actions: Actions,
        private service: StickyNoteService,
    ) { }

    @Effect() public addStickyNote = this.actions
        .pipe(
            ofType<StickyNotesAddAction>(StickyNotesActionTypes.ADD_STICKY_NOTE),
            switchMap(data => {
                return this.service.addStickyNotes(data.payload)
            }),
            map(() => {
                return new CareTeamsLoadAction()
            }),
        );
    @Effect() public editStickyNote = this.actions
        .pipe(
            ofType<StickyNotesEditAction>(StickyNotesActionTypes.EDIT_STICKY_NOTE),
            switchMap(action => {
                return this.service.updateStickyNotes(action.payload)
            }),
            map(() => {
                return new CareTeamsLoadAction()
            }),
        );
    @Effect() public deleteStickyNote = this.actions
        .pipe(
            ofType<StickyNotesDeleteAction>(StickyNotesActionTypes.DELETE_STICKY_NOTE),
            switchMap(action => {
                return this.service.deleteStickyNotes(action.noteSid, action.patientId)
            }),
            map(() => {
                return new CareTeamsLoadAction()
            }),
        );
}