export const MockPatientNotes = {
    notes: [
        {
            practiceId: 6,
            patientId: 98,
            noteSid: 1,
            timeStamp: '20191106160636',
            lastUserId: 10,
            createStamp: '20191106160636',
            createUserId: 11,
            body: 'Test Sticky Note',
            classType: 'Sticky',
        },
        {
            practiceId: 6,
            patientId: 96,
            noteSid: 2,
            timeStamp: '20191106160636',
            lastUserId: 10,
            createStamp: '20191106160636',
            createUserId: 11,
            body: 'Test Patient Note',
            classType: 'Sticky',
        }
    ]
};