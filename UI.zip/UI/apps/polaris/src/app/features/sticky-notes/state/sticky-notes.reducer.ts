import { StickyNotesModel } from '../sticky-notes.model';
import { StickyNotesActions, StickyNotesActionTypes } from './sticky-notes.actions';

export interface IStickyNotesState {
    notes: StickyNotesModel[];
}

export const defaultState: IStickyNotesState = {
    notes: [],
}

export function stickyNotesReducer(state: IStickyNotesState = defaultState, action: StickyNotesActions) {
    switch(action.type) {
        case StickyNotesActionTypes.LOAD_NOTES_SUCCESS: {
            return {
                ...state,
                notes: action.payload,
            };
        }
        case StickyNotesActionTypes.ADD_STICKY_NOTE_SUCCESS: {
            return {
                ...state,
                notes:  action.payload
            };
        }
        default: {
            return state;
        }
    }
}

export const stickyNotes = 'stickyNotesReducer';