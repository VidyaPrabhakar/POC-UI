import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { StickyNotesComponent } from './sticky-notes.component';
import { StickyNotesListComponent } from './list/sticky-notes-list.component';



@NgModule({
    imports: [
        CommonModule,
        FormsModule,
       
    ],
    declarations: [
        StickyNotesListComponent,
        StickyNotesComponent,
    ],
    exports: [
        StickyNotesListComponent,
        StickyNotesComponent,
    ],
})
export class StickyNotesModule {

}