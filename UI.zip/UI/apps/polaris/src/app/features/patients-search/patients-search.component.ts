// TODO: Feature Componetized like CrisisCenter
import { Component, OnInit, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';

import { PatientsService } from '../select-patient/patients.service';
import { PatientViewModel, PatientViewModelList } from '../select-patient/models/patientviewmodel';
import { PatientSearchModel } from '../select-patient/models/patient-model';
import { PatientSearchFacade } from './state/patients-search.facade';

@Component({
    selector: 'pol-new-patients-search',
    templateUrl: './patients-search.component.html',
    styleUrls: ['./patients-search.component.css']
})
export class PatientsSearchComponent implements OnInit {
    @Output() public OnClose = new EventEmitter<boolean>();
    public patients: PatientViewModel[] = [];
    public selectedId: number;
    public searchText = '';
    public searchMode = 'name';
    public recentPatients: PatientViewModel[] = [];

    constructor(
        private service: PatientsService,
        private router: Router,
        private patientSearchFacade: PatientSearchFacade,
        private changeDetectorRef: ChangeDetectorRef
    ) { }

    public ngOnInit() {
        const searchData = new PatientSearchModel();
        searchData.searchText = '';
        searchData.sortOrder = this.searchMode === 'name' ? '' : this.searchMode;
        searchData.assignedProviderId = '';
        this.patientSearchFacade.getAllPatient(searchData).subscribe(value => {
            if (value) {
                this.patients = value.items;
                this.changeDetectorRef.detectChanges();
            }
        });
    }
    public getPatientAvatar(patients: PatientViewModel): string {
        if (patients && patients.dnFirstName) {
            return patients.dnFirstName.split(' ').length > 1 ?
                patients.dnFirstName.split(' ')[0].charAt(0).concat(patients.dnLastName.split(' ')[1].charAt(0)) :
                patients.dnFirstName.split(' ')[0].charAt(0);
        }
    }
    public OnSelect(patient: PatientViewModel) {
        this.OnClose.emit(true);
        this.service.selectedpatient.next(patient);
        const checkPatient = this.recentPatients.find(patients => patients.patientId === patient.patientId);
        if (!checkPatient) {
            this.recentPatients.push(patient);
        }
        this.patientSearchFacade.resetPatient();
        this.router.navigate(['/home/patients/' + patient.patientId]);
    }
    public onCancel() {
        this.OnClose.emit(true);
    }

    public searchPatient(searchText: string) {
        const searchData = new PatientSearchModel();
        searchData.searchText = searchText ? searchText : '';
        searchData.sortOrder = this.searchMode === 'name' || !searchText ? '' : this.searchMode;
        searchData.assignedProviderId = '';
        this.patientSearchFacade.getAllPatient(searchData).subscribe((value: PatientViewModelList) => {
            this.patients = value.items;
            this.changeDetectorRef.detectChanges();
        });
    }
    public getRandomColor(index: number) {
        const value = index % 5;
        switch (value) {
            case 0: {
                return { 'background-color': '#8d90ce' }
            }
            case 1: {
                return { 'background-color': '#8dcea1' }
            }
            case 3: {
                return { 'background-color': '#695229' }
            }
            case 4: {
                return { 'background-color': '#cef0ea' }
            }
            default: {
                return { 'background-color': '#edc7cc' }
            }
        }

    }
}
