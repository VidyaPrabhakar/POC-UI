import { Component, OnInit, OnDestroy } from '@angular/core';
import { CareTeamFacade } from '../care-team/state/care-team.facade';
import { VitalModel } from './vital.model';
import * as moment from 'moment';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
    selector: 'pol-new-vitals',
    templateUrl: 'vitals.component.html',
    styleUrls: ['./vitals.component.css']
})


export class VitalsComponent implements OnInit, OnDestroy{
    public vitals: VitalModel[];
    public membersCount = 0;
    private ngUnsubscribe: Subject<any> = new Subject();
   
    constructor(
        private careTeamFacade: CareTeamFacade
    ) { }

    public ngOnInit() {
        this.loadPatientVitals();
    }
    public loadPatientVitals() {
        const today = moment(new Date()).format('YYYY/MM/DD');
        this.careTeamFacade.getVitals().pipe(takeUntil(this.ngUnsubscribe)).subscribe((value) => {
            if (value) {
                this.vitals = value;
                this.vitals.map((vital)=>{
                    vital.occurDate =  today === vital.occurDate ? 'Today': moment(vital.occurDate, 'YYYY/MM/DD').format('MM/DD/YY');
                    vital.occurTime = moment(vital.occurTime, 'HH:mm').format('h:mm A');
                });
                this.vitals = this.vitals.slice(0, 5);
                this.membersCount = this.vitals.length;
            }

        });
    }

    public calculateBMI(weightInKg, heightInCm) {
        let bmi = weightInKg / heightInCm / heightInCm * 10000;

        bmi = bmi > 9999 ? 9999 : bmi;

        if (bmi >= 100) {
            bmi = Math.round(bmi);
        }
        else {
            const fraction = Math.pow(10, 1);
            bmi = Math.round(bmi * fraction) / fraction;
        }
        return bmi;
    }
    public calculateBSA(weightInKg, heightInCm) {
        let bsa = Math.pow(weightInKg, 0.425) * Math.pow(heightInCm, 0.725) * 0.007184;

        bsa = bsa > 9999 ? 9999 : bsa;

        const decimal = Math.pow(10, 2);
        bsa = Math.round(bsa * decimal) / decimal;

        return bsa;
    }
    public ngOnDestroy() {
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }
}
