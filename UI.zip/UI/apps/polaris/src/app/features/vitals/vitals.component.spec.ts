import { cloneDeep } from 'lodash';
import { VitalsComponent } from "./vitals.component";
import { MockFacade } from '../care-team/state/mock-care-team.service';
import { MockCareTeam } from '../care-team/mock-data/care-team-mock-data';

describe('VitalsComponent', () => {
    let comp: VitalsComponent;
    let careTeamFacade: MockFacade;

    beforeEach(() => {
        careTeamFacade = new MockFacade();
        comp = new VitalsComponent(
            careTeamFacade as any
        );
    });

    describe('when initialized', () => {
        it('should have a defined component', () => {
            expect(comp).toBeDefined();
        });
    });

    describe('ngOnInit', () => {
        it('should call loadPatientCareTeams', () => {
            const spy = spyOn(comp, 'loadPatientVitals');
            comp.ngOnInit();
            expect(spy).toHaveBeenCalled();
        });
    });
    describe('loadPatientVitals', () => {
        it('should set the values to the care team', () => {
            comp.loadPatientVitals();
            expect(comp.vitals[0].temperatureType).toEqual(cloneDeep(MockCareTeam.patientVitals[0].temperatureType))
        });
        it('should set members count as 5', () => {
            comp.vitals = cloneDeep(MockCareTeam.patientVitals);
            comp.loadPatientVitals();
            expect(comp.membersCount).toEqual(5);
        })
    });
    describe('calculateBMI', () => {
        it('calculate bmi for height and weight', () => {
            const component = comp.calculateBMI(105, 160)
            expect(component).toEqual(41);
        })
    });
    describe('calculateBSA', () => {
        it('calculate bsi for height and weight', () => {
            const component = comp.calculateBSA(105, 160)
            expect(component).toEqual(2.06);
        })
    });
});
