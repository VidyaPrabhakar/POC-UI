
import { NgModule }      from '@angular/core';

import { FormsModule } from '@angular/forms';

import { MaterialModule } from 'app/app-matierial.module';
import { CommonModule } from '@angular/common';
import { VitalsComponent } from './vitals.component';
@NgModule({
    imports: [
      CommonModule,
      FormsModule,
      MaterialModule,
     ],
    providers: [ ],
    declarations: [ VitalsComponent ],
    exports: [
        VitalsComponent,
    ],
  
  })
  export class VitalsModule { }