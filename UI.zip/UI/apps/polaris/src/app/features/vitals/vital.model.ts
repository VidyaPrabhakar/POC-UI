export class VitalModel {
    public vitalSID: number;
    public personID: number;
    public encounterSID: number;
    public occurDate: string;
    public occurTime: string;
    public bloodPressureType: string;
    public systolicBloodPressure: number;
    public diastolicBloodPressure: number;
    public lateralityBloodPressure: string;
    public temperatureType: string;
    public pulseRate: number;
    public temperature: number;
    public weight: number;
    public height: number;
    public respiration: number;
    public headCircumference: number;
    public timeStamp: string;
    public lastUser: number;
    public createStamp: string;
    public createUser: number;
    public ounces: number;
}