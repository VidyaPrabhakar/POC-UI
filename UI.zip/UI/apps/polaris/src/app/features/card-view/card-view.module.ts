import { NgModule }      from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MaterialModule } from 'app/app-matierial.module';
import { CommonModule } from '@angular/common';
import { CardViewComponent } from './card-view.component';
import {MatCardModule} from '@angular/material/card';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MaterialModule,
    MatCardModule,
   ],
  declarations: [ CardViewComponent ],
  exports: [ CardViewComponent],

})
export class CardViewModule { }