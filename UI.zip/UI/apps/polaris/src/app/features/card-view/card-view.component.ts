
import { Component,  ChangeDetectionStrategy, Input } from '@angular/core';
import {MatCardModule} from '@angular/material/card';

@Component({
    selector: 'pol-new-card-view',
    templateUrl: 'card-view.component.html',
    styleUrls: ['./card-view.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CardViewComponent {
    @Input() public item: any;
}
