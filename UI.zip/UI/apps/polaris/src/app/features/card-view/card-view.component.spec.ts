import { CardViewComponent } from './card-view.component';
import { cloneDeep } from 'lodash';
import { MockCareTeam } from '../care-team/mock-data/care-team-mock-data';

describe('CardViewComponent', () => {
    let comp: CardViewComponent;
    beforeEach(() => {
        comp = new CardViewComponent();
        comp.item = {
            id: 1,
            description:"description",
        }
    });

    describe('when initialized', () => {
        it('should have a defined component', () => {
            expect(comp).toBeDefined();
        });
        it('should return the item id as 1', () => {
            expect(comp.item.id).toEqual(1);
        });
    });

   
});