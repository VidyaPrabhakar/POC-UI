import { Component, OnInit } from '@angular/core';
import { PatientViewModel } from 'app/features/select-patient/models/patientviewmodel';
import { PatientsService } from 'app/features/select-patient/patients.service';
import * as moment from 'moment';

@Component({
    selector: 'pol-new-patient-demographics-view',
    templateUrl: 'patient-demographics-view.component.html',
    styleUrls: ['./patient-demographics-view.component.css']
})
export class PatientDemographicsViewComponent implements OnInit {

    public currentPatient: PatientViewModel;
    public patientDateOfBirth: string;
    public patientAge: number;
    public editPatientInfo = false;
    public cancelEditPatientInfo = false;
    public editMobileTextarea: string;
    public editHomeTextarea: string;
    public editEmailTextarea: string;
    public editaddrLine1Textarea: string;
    public editaddrLine2Textarea: string;
    public editcityTextarea: string;
    public editstateTextarea: string;
    public editcountryTextarea: string;
    public editzipTextarea: string;
    public editpersonNumberTextarea: string;
    public editchartNumberTextarea: string;
    public editSSNTextarea: string;
    public editbirthDate: string;
    public editgender: string;

    constructor(private patientService: PatientsService) { }

    public ngOnInit(): void {
        this.patientService.selectedpatient.subscribe(patient => {
            this.currentPatient = patient;
        });
        this.patientDobAge(this.currentPatient.dnDOB);
    }

    public getPatientPhotoSrc() {
        let srcString = '../../../../assets/img/mockWoman.PNG';
        if(this.currentPatient) {
            if(this.patientAge < 4) {
                srcString = '../../../../assets/img/mockChild.PNG'
            } else if (this.currentPatient.dnSex === 'M') {
                srcString = '../../../../assets/img/mockMan.PNG'
            }
        }
        return srcString;
    }

    public patientSex(value): string {
        value = value === 'F' ? 'Female' : 'Male'
        return value;
    }

    public patientDobAge(value: string): void {
        this.patientDateOfBirth = moment(value, 'YYYY-MM-DDTHH:mm:ss').format('MM/DD/YYYY');
        this.patientAge = moment().diff( this.patientDateOfBirth, 'years');
    }

    public maskSsn(value: string): string {
        value = value.replace(/\d(?=\d{4})/g, "X");
        return value;
    }

    public onEditInfoClick() {
        this.editPatientInfo = true;
        this.editMobileTextarea = this.currentPatient.dnMobilePhone;
        this.editHomeTextarea = this.currentPatient.dnHomePhone;
        this.editEmailTextarea = this.currentPatient.patientEmailDetails.email;
        this.editaddrLine1Textarea = this.currentPatient.patientAddressDetails.address_line1;
        this.editaddrLine2Textarea = this.currentPatient.patientAddressDetails.address_line2;
        this.editcityTextarea = this.currentPatient.patientAddressDetails.city;
        this.editstateTextarea = this.currentPatient.patientAddressDetails.state;
        this.editcountryTextarea = this.currentPatient.patientAddressDetails.country;
        this.editzipTextarea = this.currentPatient.patientAddressDetails.zip;
        this.editpersonNumberTextarea = this.currentPatient.dnPersonNumber;
        this.editchartNumberTextarea = this.currentPatient.chartNumber;
        this.editSSNTextarea = this.maskSsn(this.currentPatient.dnSSN);
        this.editbirthDate = this.patientDateOfBirth;
        this.editgender = this.patientSex(this.currentPatient.dnSex);
    }

    public onSafeInfoClick() {

    }


}
