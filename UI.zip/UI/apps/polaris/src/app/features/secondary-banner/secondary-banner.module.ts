import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from 'app/app-matierial.module';
import { SecondBannerComponent } from './secondary-banner.component';
import { FormsModule } from '@angular/forms';

@NgModule({
    imports: [CommonModule,  MaterialModule, FormsModule],
    exports: [SecondBannerComponent],
    declarations: [SecondBannerComponent]
})
export class SecondBannerModule {}