import { Component, Input, Output, EventEmitter } from '@angular/core'

@Component({
    selector: 'pol-new-second-banner',
    templateUrl: './secondary-banner.component.html',
    styleUrls: ['./secondary-banner.component.scss']
})
export class SecondBannerComponent {
    @Input() public title: string;
    @Output() public queueClicked = new EventEmitter<boolean>();
    @Output() public closeClicked = new EventEmitter<boolean>();
    public isQueueOpen = true;
    public queueIconClick(){
        this.isQueueOpen = !this.isQueueOpen;
        this.queueClicked.emit(this.isQueueOpen);
    }
    public closeIconClick(){
        this.closeClicked.emit(true);
    }
}
