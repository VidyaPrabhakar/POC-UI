import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { HubConnection, HubConnectionBuilder } from '@aspnet/signalr';
import { PatientViewModel } from '../../features/select-patient/models/patientviewmodel';
import { PatientsService } from '../../features/select-patient/patients.service';
@Component({
    selector: 'pol-live-chat',
    templateUrl: './live-chat-dialog-component.html',
    styleUrls: ['./live-chat-dialog-component.css'],
})
export class LiveChatDialogComponent implements OnInit {
    public patient = '';
    public messageForm: FormGroup;
    public messages = [];
    textMessage = '';
    nick = '';
    private hubConnection: HubConnection;
    constructor(private dialog: MatDialog,
        private formBuilder: FormBuilder,
        private patientService: PatientsService,
    ) {
        this.createMessageForm();
    }

    ngOnInit() {
        this.patientService.selectedpatient.subscribe((patient) => {
            this.patient = patient.dnFirstName + ' ' + patient.dnMiddleName + '. '+ patient.dnLastName;
        });
        window.name =  this.patient;
        this.hubConnection = new HubConnectionBuilder().withUrl('https://localhost:44333/chatHub').build();

        this.hubConnection
            .start()
            .then(() => console.log('Connection started!'))
            .catch(err => console.log('Error while establishing connection :('));

        this.hubConnection.on('ReceiveMessage', (user: string, receivedMessage: string) => {
            const text = user + ': ' + receivedMessage;
            this.messages.push(text);
        });
    }

    public onNameCheck(msg: string): boolean {
        const words = [] = msg.split(': ');
        if (words[0] == window.name) {
            return true;
        }
        return false;
    }

    public onDialogClose() {
        this.dialog.closeAll();
    }

    public onMessageSend() {
        this.hubConnection
            .invoke('SendMessage', window.name, this.textMessage)
            .then(() => this.textMessage = '')
            .catch(err => console.error(err));
    }

    private createMessageForm() {
        this.messageForm = this.formBuilder.group({
            textMessage: ['', Validators.required]
        });
    }
}