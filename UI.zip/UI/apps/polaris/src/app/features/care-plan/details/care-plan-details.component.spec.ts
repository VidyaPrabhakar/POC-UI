import { MockFacade } from 'app/features/care-team/state/mock-care-team.service';
import { MockCareTeam } from 'app/features/care-team/mock-data/care-team-mock-data';
import { cloneDeep } from 'lodash';
import { CarePlanDetailsComponent } from './care-plan-details.component';
import { MockRouter } from 'app/features/patients-search/mock-patient-search.service';


describe('CarePlanDetailsComponent', () => {
    let comp: CarePlanDetailsComponent;
    let careTeamFacade: MockFacade;
    let route: MockRouter;

    beforeEach(() => {
        careTeamFacade = new MockFacade();
        route = new MockRouter();
        comp = new CarePlanDetailsComponent(
            careTeamFacade as any,
            route as any,
        );
    });

    describe('when initialized', () => {
        it('should have a defined component', () => {
            expect(comp).toBeDefined();
        });
    });

    describe('ngOnInit', () => {
        it('should set values to the care plan', () => {
            comp.ngOnInit();
            expect(comp.carePlans).toEqual(cloneDeep(MockCareTeam.patientCarePlan))
        });
        it('should set the length as 2', () => {
            comp.ngOnInit();
            expect(comp.carePlanCount).toEqual(2);
        })
    });

    describe('onQueueClicked', () => {
        it('should return true', () => {
            const component = comp.onQueueClicked(true);
            expect(comp.isQueueOpen).toBeTruthy();
        });
        it('should return false', () => {
            const component = comp.onQueueClicked(false);
            expect(comp.isQueueOpen).toBeFalsy();
        });
    });
    describe('onCloseClicked', () => {
        it('should call navigate when careteam is undefined', () => {
            comp.carePlans = undefined;
            const spy = spyOn(route, 'navigate');
            comp.onCloseClicked(true);
            expect(spy).toHaveBeenCalled();
        });
        it('should call navigate when careteam contains value', () => {
            comp.carePlans = cloneDeep(MockCareTeam.patientCarePlan)
            const spy = spyOn(route, 'navigate');
            comp.onCloseClicked(true);
            expect(spy).toHaveBeenCalled();
        });
    });
})
