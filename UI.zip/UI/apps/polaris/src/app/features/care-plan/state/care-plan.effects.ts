import { Actions, Effect, ofType } from '@ngrx/effects';
import { Injectable } from '@angular/core';
import {
    CarePlanLoadAction,
    CarePlanAddAction,
    CarePlanActionTypes
} from './care-plan.actions';
import { switchMap, map, mergeMap } from 'rxjs/operators';
import { CarePlanService } from '@polaris/api/services';
import { CareTeamsLoadAction } from 'app/features/care-team/state/care-team.actions';

@Injectable()
export class CarePlanEffects {
    constructor(protected actions: Actions,
        private service: CarePlanService,
    ) { }

    @Effect() public addCarePlan = this.actions
        .pipe(
            ofType<CarePlanAddAction>(CarePlanActionTypes.ADD_CARE_PLAN),
            switchMap(data => {
                return this.service.addCarePlanGoal(data.careplan);
            }),
            map(() => {
                return new CareTeamsLoadAction()
            }),
        );
}