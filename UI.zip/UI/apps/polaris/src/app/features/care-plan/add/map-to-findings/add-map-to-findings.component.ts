import {
    Component,
    OnInit,
    Input,
    Output,
    EventEmitter,
    ChangeDetectionStrategy,
    ChangeDetectorRef,
} from '@angular/core';
import { take } from 'rxjs/operators';
import { SaveCarePlanResponse } from 'app/features/care-plan/add/save-care-plan.response';
import * as _ from 'lodash';
@Component({
    selector: 'pol-add-map-to-findings',
    templateUrl: './add-map-to-findings.component.html',
    styleUrls: ['../add-care-plan-dialog.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    preserveWhitespaces: false,
})
export class AddMapToFindingsComponent implements OnInit {
    @Input() public section;
    @Output() public selectIndex = new EventEmitter<string>();

    //protected sectionsTitles = CarePlanSectionsTitles;
    public providerId: string;
    public patientId: string;
    public diagnosisId: string;

    constructor(
        public response: SaveCarePlanResponse,
      //  private appFacade: AppFacade,
        public changeDetectorRef: ChangeDetectorRef,
    ) {}

    public ngOnInit() {
     //   this.setCurrentPatient();
    }

    public setCurrentIndex(currentIndex: string) {
        this.selectIndex.emit(currentIndex);
    }
    // private setCurrentPatient(): void {
    //     this.appFacade.currentPatient.pipe(take(1)).subscribe((currentPatient: PatientViewModel) => {
    //         if (currentPatient) {
    //             this.patientId = currentPatient.patientId;
    //             this.providerId = currentPatient.assignedProviderId;
    //             this.changeDetectorRef.detectChanges();
    //         }
    //     });
    // }
    // public onfindingSelectedEvent(propertyRecords: FindingPropertyRecord[]) {
    //     if (propertyRecords[0]) {
    //         const lastFinding = _.last(this.response.patientCarePlanGoal.findingDescriptions);
    //         if (lastFinding && Number(lastFinding.code) == propertyRecords[0].parentMedcinID) {
    //             const index = this.response.patientCarePlanGoal.findingDescriptions.length - 1;
    //             this.response.patientCarePlanGoal.findingDescriptions[index] = new CodedItem(
    //                 propertyRecords[0].medcinId,
    //                 propertyRecords[0].fullDescription,
    //             );
    //         } else {
    //             this.response.patientCarePlanGoal.findingDescriptions.push(
    //                 new CodedItem(propertyRecords[0].medcinId, propertyRecords[0].fullDescription),
    //             );
    //         }
    //         this.response.patientCarePlanGoal.medcinId = Number(propertyRecords[0].medcinId);
    //     }
    // }
}
