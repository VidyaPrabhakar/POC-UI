export interface ICodedItem {
    code: string;
    description: string;
}

export class CodedItem implements ICodedItem {
    constructor(public code: string, public description: string) {}
}