import { Component, OnInit, OnDestroy } from '@angular/core'
import { CareTeamFacade } from 'app/features/care-team/state/care-team.facade';
import { LastUserName, PatientCarePlan } from '../models/care-plan.model';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { AddCarePlanComponent } from '../add';

@Component({
    selector: 'pol-new-care-plan-widget',
    templateUrl: './care-plan-widget.component.html',
    styleUrls: ['./care-plan-widget.component.css']
})
export class CarePlanWidgetComponent implements OnInit, OnDestroy {
    public carePlans: PatientCarePlan[];
    public carePlanCount: number;
    private ngUnsubscribe: Subject<any> = new Subject();

    constructor(
        private careTeamFacade: CareTeamFacade,
        protected router: Router,
        protected route: ActivatedRoute,
        public dialog: MatDialog) { }

    public ngOnInit() {
        this.careTeamFacade.getCarePlans().pipe(takeUntil(this.ngUnsubscribe)).subscribe(value => {
            if (value) {
                this.carePlans = value;
                this.carePlanCount = this.carePlans.length;
            }
        });
    }

    public getLastUserName(lastUserId: number) {
        const lastUserName = LastUserName.find(data => data.id === lastUserId).value;
        return lastUserName;
    }
    public onCarePlanClick(carePlan?: PatientCarePlan) {
        this.router.navigate(['care-plan'], {
            queryParams: { id: carePlan ? carePlan.patientCareplanGoalSid : undefined },
            relativeTo: this.route,
        });
    }
    public ngOnDestroy() {
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }
    public addCarePlan(){
        const dialogRef = this.dialog.open(AddCarePlanComponent, {
            width: '800px'
        });
    }
}
