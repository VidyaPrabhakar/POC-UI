import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { SaveCarePlanResponse } from 'app/features/care-plan/add/save-care-plan.response';
import { CarePlanSectionsTitles, CarePlanInitiatedBy, CarePlanStatuses } from '../../models';
@Component({
    selector: 'pol-add-initiated-by',
    templateUrl: './add-initiated-by.component.html',
    styleUrls: ['../add-care-plan-dialog.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AddInitiatedByComponent implements OnInit {
    @Input() public section;
    @Input() public fields;
    @Input() public isAdd;
    @Output() public selectIndex = new EventEmitter<string>();

    public sectionsTitles = CarePlanSectionsTitles;
    public initiatedBy = CarePlanInitiatedBy.enumerable;
    public status = CarePlanStatuses.enumerable;
    constructor(public response: SaveCarePlanResponse) { }

    public ngOnInit() { }

    public setCurrentIndex(currentIndex: string) {
        this.selectIndex.emit(currentIndex);
    }
    public selectInitiateBy(selected) {
        this.response.patientCarePlanGoal.initiatedBy = selected.description;
    }
    public selectStatus(selected) {
        this.response.patientCarePlanGoal.goalStatus = selected.code;
        this.response.patientCarePlanGoal.goalStatusText = selected.description;
    }
}
