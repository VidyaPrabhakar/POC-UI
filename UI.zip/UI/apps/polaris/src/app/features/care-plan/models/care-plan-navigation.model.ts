import { CodedItem } from './coded-item';

export class CarePlanSection {
    constructor(readonly title: string) {}
}

export class CarePlanSectionRow {
    constructor(readonly sectionTitle: string, readonly sections: CarePlanSection[], public visible: boolean = false) {}
}

export class CarePlanSectionsData {
    constructor(readonly isNew: boolean, readonly sections: CarePlanSectionRow[]) {}
}

export const CarePlanSectionsTitles = {
    goal: 'Goal',
    initiatedBy: 'Initiated By',
    mapToFindings: 'Map To Findings',
    hideFromPatient: 'Hide From Patient',
    status: 'Status',
    findings: 'Findings',
    initiatedByAndStatus: 'Initiated By/Status',
};

export class CarePlanInitiatedBy {
    public static readonly provider = new CodedItem('PROV', 'Provider');
    public static readonly patient = new CodedItem('PAT', 'Patient');
    public static readonly both = new CodedItem('BOTH', 'Both');

    public static enumerable: CodedItem[] = [
        CarePlanInitiatedBy.provider,
        CarePlanInitiatedBy.patient,
        CarePlanInitiatedBy.both,
    ];
}

export enum CarePlanStatus {
    InProgress= 'A',
    Completed= 'C',
    Void = 'V',
 }
export class CarePlanStatuses {
    public static readonly completed = new CodedItem('C', 'Completed');
    public static readonly inProgress = new CodedItem('I', 'In Progress');
    public static readonly void = new CodedItem('V', 'Voided');

    public static enumerable: CodedItem[] = [
        CarePlanStatuses.completed,
        CarePlanStatuses.inProgress,
        CarePlanStatuses.void,
    ];
}