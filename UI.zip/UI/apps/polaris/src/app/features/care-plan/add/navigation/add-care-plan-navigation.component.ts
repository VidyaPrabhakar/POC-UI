import { Component, Output, EventEmitter, Input } from '@angular/core';
import { SaveCarePlanResponse } from 'app/features/care-plan/add/save-care-plan.response';
import { CarePlanSectionsTitles } from '../../models';

@Component({
    selector: 'pol-add-care-plan-navigation',
    templateUrl: './add-care-plan-navigation.component.html',
    styleUrls: ['../add-care-plan-dialog.component.css'],
})
export class AddCarePlanNavigationComponent {
    @Input() public fields;
    @Input() public editor: string;
    @Input() public currentIndex: string;
    @Output() public selectIndex = new EventEmitter<string>();

    public sectionsTitles = CarePlanSectionsTitles;

    constructor(public response: SaveCarePlanResponse) {}

    public setCurrentIndex(currentIndex: string) {
        this.selectIndex.emit(currentIndex);
    }
    public trackByIndex(index: number) {
        return index;
    }
    public getHideFromPatient(index: number) {
        return this.response.patientCarePlanGoal.hideFromPatient ? 'Yes' : 'No';
    }
}