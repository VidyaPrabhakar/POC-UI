import { Component, OnInit, OnDestroy } from '@angular/core'
import { CareTeamFacade } from 'app/features/care-team/state/care-team.facade';
import { PatientCarePlan } from '../models/care-plan.model';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { Router } from '@angular/router';
import { DetailsViewModel } from 'app/features/details-view/details-view.model';

@Component({
    selector: 'pol-new-care-plan-details',
    templateUrl: './care-plan-details.component.html',
    styleUrls: ['./care-plan-details.component.css']
})
export class CarePlanDetailsComponent implements OnInit, OnDestroy {
    public carePlans: PatientCarePlan[];
    public carePlanCount: number;
    private ngUnsubscribe: Subject<any> = new Subject();
    public isQueueOpen = true;
    public detailsViewModel = new DetailsViewModel();

    constructor(
        private careTeamFacade: CareTeamFacade,
        protected router: Router,
       ) { }
 
    public ngOnInit() {
        this.careTeamFacade.getCarePlans().pipe(takeUntil(this.ngUnsubscribe)).subscribe(value => {
            if (value) {
                this.carePlans = value;
                this.carePlanCount = this.carePlans.length;
            }
        });
        this.detailsViewModel = {
            title: "Goals",
            count: this.carePlanCount,
            details: this.carePlans,
            isQueueOpen: this.isQueueOpen,
            typeOf: "PatientCarePlan"
        }
    }
    public onQueueClicked(value: boolean){
        this.isQueueOpen = value;
        this.detailsViewModel.isQueueOpen = value;
    }
    public onCloseClicked(value:boolean){
        if(this.carePlans && this.carePlans[0] ){
            this.router.navigate(['/home/patients/' + this.carePlans[0].patientId]);
        }else{
            this.router.navigate(['/home/patients']);
        }

    }
    public ngOnDestroy() {
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }
}
