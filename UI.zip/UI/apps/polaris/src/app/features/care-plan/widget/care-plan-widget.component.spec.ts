import { CarePlanWidgetComponent } from "./care-plan-widget.component"
import { MockFacade } from 'app/features/care-team/state/mock-care-team.service';
import { MockCareTeam } from 'app/features/care-team/mock-data/care-team-mock-data';
import { cloneDeep } from 'lodash';
import { MockRouter } from 'app/features/patients-search/mock-patient-search.service';
import { Subject } from 'rxjs';

class MockActivatedRoute {
    public queryParams = new Subject<any>();
    public parent: any;
}

describe('CarePlan', () => {
    let comp: CarePlanWidgetComponent;
    let careTeamFacade: MockFacade;
    let route: MockRouter;

    beforeEach(() => {
        careTeamFacade = new MockFacade();
        route = new MockRouter();
        comp = new CarePlanWidgetComponent(
            careTeamFacade as any,
            route as any,
            new MockActivatedRoute() as any,
        );
    });

    describe('when initialized', () => {
        it('should have a defined component', () => {
            expect(comp).toBeDefined();
        });
    });

    describe('ngOnInit', () => {
        it('should set values to the care plan', () => {
            comp.ngOnInit();
            expect(comp.carePlans).toEqual(cloneDeep(MockCareTeam.patientCarePlan))
        });
        it('should set the length as 2', () => {
            comp.ngOnInit();
            expect(comp.carePlanCount).toEqual(2);
        })
    });

    describe('getLastUserName', () => {
        it('should return the last user name', () => {
            const lastUser = comp.getLastUserName(37);
            expect(lastUser).toEqual('David Ford MD');
        });
    });
    describe('onCarePlanClick', () => {
        it('should call navigate when careteam is undefined', () => {
            const spy = spyOn(route, 'navigate');
            comp.onCarePlanClick();
            expect(spy).toHaveBeenCalled();
        });
        it('should call navigate when careteam contains value', () => {
            const spy = spyOn(route, 'navigate');
            comp.onCarePlanClick(MockCareTeam.patientCarePlan[0]);
            expect(spy).toHaveBeenCalled();
        });
    });
})
