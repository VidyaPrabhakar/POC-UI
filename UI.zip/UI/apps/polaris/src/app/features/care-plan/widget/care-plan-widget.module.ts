import { NgModule } from '@angular/core';
import { CarePlanWidgetComponent } from './care-plan-widget.component';
import { CommonModule } from '@angular/common';
import { MaterialModule } from 'app/app-matierial.module';
import { CarePlanDetailsComponent } from '../details/care-plan-details.component';
import { SecondBannerModule } from 'app/features/secondary-banner/secondary-banner.module';
import { DetailsViewModule } from 'app/features/details-view/details-view.module';
import { AddGoalComponent, AddInitiatedByComponent, AddMapToFindingsComponent, AddCarePlanNavigationComponent, SaveCarePlanResponse } from '../add';
import { FormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { carePlanReducer } from '../state/care-plan.reducer';
import { CarePlanEffects } from '../state/care-plan.effects';
import { CarePlanFacade } from '../state/care-plan.facade';

@NgModule({
    imports: [
        CommonModule,
        MaterialModule,
        SecondBannerModule,
        DetailsViewModule,
        FormsModule,
        StoreModule.forFeature('carePlanReducer', carePlanReducer),
        EffectsModule.forFeature([CarePlanEffects]),
    ],
    exports: [
        CarePlanWidgetComponent,
        CarePlanDetailsComponent,
        AddGoalComponent,
        AddInitiatedByComponent,
        AddMapToFindingsComponent,
        AddCarePlanNavigationComponent
    ],
    declarations: [
        CarePlanWidgetComponent,
        CarePlanDetailsComponent,
        AddGoalComponent,
        AddInitiatedByComponent,
        AddMapToFindingsComponent,
        AddCarePlanNavigationComponent
    ],
    providers: [SaveCarePlanResponse, CarePlanFacade],
})
export class CarePlanWidgetModule { }