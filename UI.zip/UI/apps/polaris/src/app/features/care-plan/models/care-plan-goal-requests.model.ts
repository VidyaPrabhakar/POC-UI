import { CodedItem } from './coded-item';
export class CarePlanGoalRequest {
    // public uniqueID: string;
    // public parentUnique: string;
    // public patientUnique: string;
    // public description: string;
    // public hideFromPatient: boolean;
    // public goalStatus: string;
    // public goalStatusText: string;
    // public timeStamp: string;
    // public lastUserName: string;
    // public lastUserLogon: string;
    // public medcinId: number;
    // public medcinPrefix: string;
    // public authorType: string;
    // public goalUpdated: boolean;
    // public goalGUID: string;
    // public source: string;
    // public externalUserLogon: string;
    // public externalUserFullName: string;
    // public createString: string;
    // public dateString: string;
    // public goalHistoryAdditionalToolTipInfo: string;
    // public initiatedBy: string;
    // public findingDescriptions: CodedItem[];

    public patientCareplanGoalSid: number;
    public practiceId: number;
    public patientId: number;
    public description: string;
    public hideFromPatient: boolean;
    public goalStatus: string;
    public goalStatusText: string;
    public timeStamp: string;
    public lastUser: number;
    public createStamp: string;
    public createUser: number;
    public medicinId: number;
    public medicinPrefix: string;
    public authorType: string;
    public isDeleted: number;
    public initiatedBy: string;
}
export class CarePlanGoalRequests {
    public patientCarePlanGoal: CarePlanGoalRequest;
}
