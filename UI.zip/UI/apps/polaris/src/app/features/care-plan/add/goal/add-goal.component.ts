import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { SaveCarePlanResponse } from 'app/features/care-plan/add/save-care-plan.response';
import { CarePlanSectionsTitles } from '../../models';

@Component({
    selector: 'pol-add-goal',
    templateUrl: './add-goal.component.html',
    styleUrls: ['../add-care-plan-dialog.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AddGoalComponent implements OnInit {
    @Input() public section;
    @Output() public selectIndex = new EventEmitter<string>();

    protected sectionsTitles = CarePlanSectionsTitles;
    // public quickTextContext: IQuickTextModalContext = {
    //     type: QuickTextType.carePlanGoals,
    //     mode: QuickTextModalMode.Select,
    //     subType: 'GoalGeneral',
    // };
    public description;

    constructor(public response: SaveCarePlanResponse) { }

    public ngOnInit() {
        this.description = this.response.patientCarePlanGoal.description
            ? this.response.patientCarePlanGoal.description
            : '';
    }

    public setCurrentIndex(currentIndex: string) {
        this.selectIndex.emit(currentIndex);
    }
    public onQuickTextSelected(selectedQuickText: string): void {
        if (selectedQuickText) {
            if (this.description) {
                this.description = this.description + ' ' + selectedQuickText;
            } else {
                this.description = selectedQuickText;
            }

        }
    }
    public onKeyUp() {
        this.response.patientCarePlanGoal.description = this.description;
    }
}
