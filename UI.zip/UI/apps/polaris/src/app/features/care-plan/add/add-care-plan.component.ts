import {
    Component,
    OnInit,
    ChangeDetectionStrategy,
} from '@angular/core';

import { Subject, combineLatest as observableCombineLatest, of as observableOf } from 'rxjs';
import { takeUntil, take, switchMap } from 'rxjs/operators';

import { SaveCarePlanResponse } from './save-care-plan.response';
import * as moment from 'moment';
import * as _ from 'lodash';
import { MatDialogRef } from '@angular/material/dialog';
import { CarePlanSectionsData, CarePlanSectionsTitles, PatientCarePlan, CarePlanSectionRow, CarePlanSection, CarePlanGoalRequest, CarePlanInitiatedBy, CarePlanStatus } from '../models';
import { PatientsService } from 'app/features/select-patient/patients.service';
import { PatientViewModel } from 'app/features/select-patient/models/patientviewmodel';
import { CarePlanFacade } from '../state/care-plan.facade';

@Component({
    selector: 'pol-add-care-plan',
    templateUrl: 'add-care-plan.component.html',
    styleUrls: ['./add-care-plan-dialog.component.css'],
    host: {
        class: 'module--carePlan',
    },
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AddCarePlanComponent implements OnInit {
    public sectionsTitles = CarePlanSectionsTitles;
    public currentIndex = this.sectionsTitles.goal;
    public originalCarePlanData;
    public carePlanSectionsData: CarePlanSectionsData;
    public fields: CarePlanSectionsData;
    public patients: PatientViewModel;
    public today = Date.now();

    constructor(public dialogRef: MatDialogRef<AddCarePlanComponent>, public response: SaveCarePlanResponse,
        private patientService: PatientsService, private careplanFacade: CarePlanFacade) { }

    public ngOnInit() {
        this.patientService.selectedpatient.subscribe((patient) => {
            this.patients = patient;
        });
        this.setUpKeys();
    }

    public setUpKeys() {
        this.response.patientCarePlanGoal = new CarePlanGoalRequest();
        this.carePlanSectionsData = this.loadAddEditCarePlanTemplate(undefined);
        this.fields = this.carePlanSectionsData;
        this.getCarePlan();
        this.currentIndex = this.fields.sections[0].sectionTitle;
    }
    public onCancel(): void {
        this.dialogRef.close('cancel');
    }

    public onSave() {
        const careplan: CarePlanGoalRequest = new CarePlanGoalRequest();
        careplan.practiceId = 1;
        careplan.patientId = this.patients.patientId;
        careplan.description = this.response.patientCarePlanGoal.description;
        careplan.goalStatus = this.getGoalStatus(this.response.patientCarePlanGoal.goalStatusText);
        careplan.isDeleted = 0;
        careplan.medicinId = 0;
        careplan.medicinPrefix = '';
        careplan.authorType = this.getAuthorType(this.response.patientCarePlanGoal.initiatedBy);
        careplan.lastUser = 37;
        careplan.createUser = 37;
        careplan.hideFromPatient = this.response.patientCarePlanGoal.hideFromPatient;
        this.careplanFacade.addCarePlan(careplan);
        this.dialogRef.close('cancel');
    }

    private getAuthorType(initiatedBy: string) {
        switch (initiatedBy) {
            case 'Provider':
                return CarePlanInitiatedBy.provider.code;
            case 'Patient':
                return CarePlanInitiatedBy.patient.code;
            case 'Both':
                return CarePlanInitiatedBy.both.code;
            default:
                return '';
        }
    }

    private getGoalStatus(goalStatus: string) {
        switch (goalStatus) {
            case 'In Progress':
                return CarePlanStatus.InProgress;
            case 'Completed':
                return CarePlanStatus.Completed;
            case 'Void':
                return CarePlanStatus.Void;
            default:
                return '';
        }
    }

    public getCarePlan() {
        this.response.patientCarePlanGoal.goalStatus = 'I';
        this.response.patientCarePlanGoal.goalStatusText = 'In Progress';
        this.response.patientCarePlanGoal.initiatedBy = 'Provider';
        this.response.patientCarePlanGoal.hideFromPatient = false;
    }

    public loadAddEditCarePlanTemplate(carePlan: PatientCarePlan) {
        const carePlanSectionsData: CarePlanSectionsData = {
            isNew: !carePlan,
            sections: [
                new CarePlanSectionRow(
                    this.sectionsTitles.goal,
                    [
                        new CarePlanSection(this.sectionsTitles.goal),
                        new CarePlanSection(this.sectionsTitles.hideFromPatient),
                    ],
                    true,
                ),
                new CarePlanSectionRow(
                    this.sectionsTitles.findings,
                    [new CarePlanSection(this.sectionsTitles.mapToFindings)],
                    true,
                ),
                new CarePlanSectionRow(
                    this.sectionsTitles.initiatedByAndStatus,
                    [
                        new CarePlanSection(this.sectionsTitles.initiatedBy),
                        new CarePlanSection(this.sectionsTitles.status),
                    ],
                    true,
                ),
            ],
        };
        return carePlanSectionsData;
    }

    public selectIndex(selectedIndex: string) {
        this.currentIndex = selectedIndex;
    }
}
