import { PatientCarePlan } from '../models';
import { CarePlanActions, CarePlanActionTypes } from './care-plan.actions';

export interface ICarePlanState {
    careplan: PatientCarePlan[];
}

export const defaultState: ICarePlanState = {
    careplan: [],
}

export function carePlanReducer(state: ICarePlanState = defaultState, action: CarePlanActions) {
    switch(action.type) {
        case CarePlanActionTypes.LOAD_CARE_PLAN: {
            return {
                ...state,
                notes: action.payload,
            };
        }
        case CarePlanActionTypes.ADD_CARE_PLAN: {
            return {
                ...state,
                notes:  action.careplan
            };
        }
        default: {
            return state;
        }
    }
}

export const careplan = 'carePlanReducer';