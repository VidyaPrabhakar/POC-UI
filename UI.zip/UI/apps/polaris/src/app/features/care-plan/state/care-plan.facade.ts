import { Injectable, OnInit } from "@angular/core";
import { Store } from '@ngrx/store';
import { ICarePlanState } from './care-plan.reducer';
import * as searchActions from './care-plan.actions';

export interface AppState {
    readonly goals: ICarePlanState
  }

@Injectable()
export class CarePlanFacade {
    constructor(private store: Store<AppState>) { }

    public readonly goalsView = this.store.select(store => store.goals);

    public addCarePlan(carePlan) {
        this.store.dispatch(new searchActions.CarePlanAddAction(carePlan));
    }

    public editCarePlan(editedNote) {
        this.store.dispatch(new searchActions.CarePlanEditAction(editedNote));
    }
}