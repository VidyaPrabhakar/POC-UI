import { Injectable } from '@angular/core';
import { CarePlanGoalRequests } from '../models';

@Injectable()
export class SaveCarePlanResponse {
    public save: CarePlanGoalRequests = new CarePlanGoalRequests();
    public patientCarePlanGoal = this.save.patientCarePlanGoal;
}
