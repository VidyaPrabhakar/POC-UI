import { Action } from '@ngrx/store';
import { PatientCarePlan, CarePlanGoalRequests, CarePlanGoalRequest } from '../models';

export enum CarePlanActionTypes {
    LOAD_CARE_PLAN = '[Care Plan] Load',
    LOAD_CARE_PLAN_SUCCESS = '[Care Plan] Load Success',

    ADD_CARE_PLAN = '[Care Plan] Add Care Plan',
    ADD_CARE_PLAN_SUCCESS = '[Care Plan] Add Care Plan Success',
    EDIT_CARE_PLAN = '[Care Plan] Edit Care Plan',
}

export class CarePlanLoadAction implements Action {
    public readonly type = CarePlanActionTypes.LOAD_CARE_PLAN;
    constructor(public payload?, public useCache: boolean = true) {}
}

export class CarePlanLoadSuccessAction implements Action {
    public readonly type = CarePlanActionTypes.LOAD_CARE_PLAN_SUCCESS;
    constructor(public payload: PatientCarePlan[]) {}
}

export class CarePlanAddAction implements Action {
    public readonly type = CarePlanActionTypes.ADD_CARE_PLAN;
    constructor(public careplan: CarePlanGoalRequest) {}
}
export class CarePlanAddSuccessAction implements Action {
    public readonly type = CarePlanActionTypes.ADD_CARE_PLAN_SUCCESS;
    constructor() {}
}

export class CarePlanEditAction implements Action {
    public readonly type = CarePlanActionTypes.EDIT_CARE_PLAN;
    constructor(public payload: CarePlanGoalRequest) { }
}

export type CarePlanActions =
    | CarePlanLoadAction
    | CarePlanLoadSuccessAction
    | CarePlanAddAction
    | CarePlanAddSuccessAction
    | CarePlanEditAction;