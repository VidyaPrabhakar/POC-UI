
export class PatientCarePlan {
    public patientCareplanGoalSid: number;
    public practiceId: number;
    public patientId: number;
    public description: string;
    public HideFromPatient: boolean;
    public goalStatus: string;
    public timeStamp: string;
    public lastUser: number;
    public createStamp: string;
    public createUser: number;
    public medicinId: number;
    public medicinPrefix: string;
    public authorType: string;

    /**
     *
     */
    constructor() {
        

    }
}
export const LastUserName = [
    {
        id: 37,
        value: 'David Ford MD'
    },
    {
        id: 38,
        value: ' David Ford MD'
    },
    {
        id: 39,
        value: 'Albert Davis MD'
    },
    {
        id: 450,
        value: 'Detrasnik, Jason K. MD'
    }
];