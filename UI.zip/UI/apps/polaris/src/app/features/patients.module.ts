import { NgModule }       from '@angular/core';
import { CommonModule }   from '@angular/common';
import { FormsModule, ReactiveFormsModule }    from '@angular/forms';
import { PatientsRoutingModule } from './patients-routing.module';
import { PatientDetailsComponent } from '../features/select-patient/patient-details/patient-details.component';
import { StickyNotesDialogComponent } from './sticky-notes/sticky-notes-dialog/sticky-notes-dialog.component';
import { MaterialModule } from '../app-matierial.module';
import { StickyNotesFacade } from './sticky-notes/state/sticky-notes.facade';
import { AlertModalComponent } from './sticky-notes/common/alert-modal/alert-modal.component';
import { CareTeamModule } from '@polaris/features/care-team/care-team.module';
import { StickyNotesModule } from './sticky-notes/sticky-notes.module';
import { ChatbotModule } from '@polaris/features/chatbot/chatbot.module';
import { ChatbotComponent } from './chatbot/chatbot.component';
import { VitalsModule } from './vitals/vitals.module';
import { CarePlanWidgetModule } from './care-plan/widget/care-plan-widget.module';
import { AddCarePlanComponent } from './care-plan/add';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    PatientsRoutingModule,
    MaterialModule,
    CareTeamModule,
    StickyNotesModule,
    ChatbotModule,
    VitalsModule,
    CarePlanWidgetModule
  ],
  declarations: [
    PatientDetailsComponent,
    StickyNotesDialogComponent,
    AlertModalComponent,
    AddCarePlanComponent
  ],
  providers: [
    StickyNotesFacade,
  ],
  exports: [
  ],
  entryComponents: [ 
      StickyNotesDialogComponent,
      AlertModalComponent,
      ChatbotComponent,
      AddCarePlanComponent
     ]
})
export class PatientsModule {}