import { Subject } from 'rxjs';
import { CareTeamDetailsComponent } from './care-team-details.component';
import { MockFacade } from '../state/mock-care-team.service';
import { MockRouter } from 'app/features/patients-search/mock-patient-search.service';
import { cloneDeep } from 'lodash';
import { MockCareTeam } from '../mock-data/care-team-mock-data';
class MockActivatedRoute {
    public queryParams = new Subject<any>();
    public parent: any;
}
describe('CareTeamDetailsComponent', () => {
    let comp: CareTeamDetailsComponent;
    let careTeamFacade: MockFacade;
    let route: MockRouter;
    beforeEach(() => {
        careTeamFacade = new MockFacade();
        route = new MockRouter();
        comp = new CareTeamDetailsComponent(
            careTeamFacade as any,
            route as any,
        );
    });

    describe('when initialized', () => {
        it('should have a defined component', () => {
            expect(comp).toBeDefined();
        });
    });

    describe('ngOnInit', () => {
        it('should call loadPatientCareTeams', () => {
            const spy = spyOn(comp, 'loadPatientCareTeams');
            comp.ngOnInit();
            expect(spy).toHaveBeenCalled();
        });
    });

    describe('loadPatientCareTeams', () => {
        it('should set the values to the care team', () => {
            comp.loadPatientCareTeams();
            expect(comp.careTeam[1].specialtyCode).toBe("3416A0800X");
        });
        it('should set members count as 1', () => {
            comp.loadPatientCareTeams();
            expect(comp.membersCount).toEqual(2);
        })
    });

    describe('onQueueClicked', () => {
        it('should return true', () => {
            const component = comp.onQueueClicked(true);
            expect(comp.isQueueOpen).toBeTruthy();
        });
        it('should return false', () => {
            const component = comp.onQueueClicked(false);
            expect(comp.isQueueOpen).toBeFalsy();
        });
    });
    describe('onCloseClicked', () => {
        it('should call navigate when careteam is undefined', () => {
            comp.careTeam = undefined;
            const spy = spyOn(route, 'navigate');
            comp.onCloseClicked(true);
            expect(spy).toHaveBeenCalled();
        });
        it('should call navigate when careteam contains value', () => {
            comp.careTeam = cloneDeep(MockCareTeam.patientCareTeams)
            const spy = spyOn(route, 'navigate');
            comp.onCloseClicked(true);
            expect(spy).toHaveBeenCalled();
        });
    });
    
});