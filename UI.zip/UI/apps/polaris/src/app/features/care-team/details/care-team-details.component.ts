import { Component, OnInit } from '@angular/core';
import { PatientCareTeam } from '../models/care-team.model';
import { CareTeamFacade } from '../state/care-team.facade';
import { Router } from '@angular/router';
import { DetailsViewModel } from 'app/features/details-view/details-view.model';

@Component({
    selector: 'pol-new-care-team-details',
    templateUrl: 'care-team-details.component.html',
    styleUrls: ['./care-team-details.component.css']
})
export class CareTeamDetailsComponent implements OnInit {

    public careTeam: PatientCareTeam[]; 
    public membersCount = 0;
    public patientId: number;
    public isQueueOpen = true;
    public detailsViewModel = new DetailsViewModel();

    constructor(
        private careTeamFacade: CareTeamFacade,
        protected router: Router,
        ) {}

    public ngOnInit() {
        this.loadPatientCareTeams();
    }
    public loadPatientCareTeams() {
        this.careTeamFacade.getCareTeams().subscribe((value) => {
            if(value){
                this.careTeam = value;
                this.membersCount = this.careTeam.length;
            }
        });
        this.detailsViewModel = {
            title: "Care Team",
            count: this.membersCount,
            details: this.careTeam,
            isQueueOpen: this.isQueueOpen,
            typeOf: "PatientCareTeam"
        }
    }
    public onQueueClicked(value: boolean){
        this.isQueueOpen = value;
        this.detailsViewModel.isQueueOpen = value;
    }
    public onCloseClicked(value:boolean){
        if(this.careTeam && this.careTeam[0] ){
            this.router.navigate(['/home/patients/' + this.careTeam[0].patientId]);
        }else{
            this.router.navigate(['/home/patients']);
        }

    }
}
