import { Injectable, Compiler } from '@angular/core';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { UserManager, UserManagerSettings, User } from 'oidc-client';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  isLoggedIn = false;

  // store the URL so we can redirect after logging in
  redirectUrl: string;

  private _authNavStatusSource = new BehaviorSubject<boolean>(false);
  // Observable navItem stream
  authNavStatus$ = this._authNavStatusSource.asObservable();
  private user: User | null;
  private mgr = new UserManager(getClientSettings());

  constructor(private http: HttpClient) {
    this.mgr.signinRedirectCallback();
    this.mgr.getUser().then((user) => {
      if (user) {
        this.user = user;
        // localStorage.setItem('access_token', user.access_token);
        // localStorage.setItem('loggedinUser', user.expired.toString());
        sessionStorage.setItem('access_token', user.access_token);
        sessionStorage.setItem('loggedinUser', user.expired.toString());
      }
    });
  }


  async getUser() {
    this.mgr.signinRedirectCallback();
    this.user = await this.mgr.getUser();
  }

  logout(): void {
    this.isLoggedIn = false;
    this.mgr.signoutRedirect();
  }

  login() {
    this.isLoggedIn = true;
    this.mgr.signinRedirect();
  }

  async completeAuthentication() {
    this.user = await this.mgr.signinRedirectCallback();
    this.mgr.getUser().then((user) => {
      this.user = user;
    });
  }

  isAuthenticated(): boolean {
    return this.user != null && !this.user.expired;
  }

  get authorizationHeaderValue(): string {
    if (this.user != null) {
      return `${this.user.token_type} ${this.user.access_token}`;
    }
  }

  get name(): string {
    return this.user != null ? this.user.profile.name : '';
  }
}


export function getClientSettings(): UserManagerSettings {
  return {
    authority: 'http://localhost:5001',
    client_id: 'polaris',
    redirect_uri: 'http://localhost:4200/select-practice',
    post_logout_redirect_uri: 'http://localhost:4200',
    response_type: "id_token token",
    scope: "openid profile polaris_api",
    filterProtocolClaims: true,
    loadUserInfo: true,
    automaticSilentRenew: true,
    silent_redirect_uri: 'http://localhost:4200/select-practice'
  };
}
