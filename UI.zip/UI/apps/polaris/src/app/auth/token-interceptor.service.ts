import { Injectable, Injector } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { AuthService } from './auth.service';
import { Observable, of } from 'rxjs';
import { switchMap, map, catchError } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable()
export class TokenInterceptorService implements HttpInterceptor {
    private authService: AuthService;
    constructor(private router: Router, private auth: AuthService) { }
    // test = sessionStorage.getItem('oidc.user:http://localhost:5001:polaris');
    // obj = JSON.parse(this.test);
    // obj1= JSON.parse(sessionStorage.getItem('oidc.user:http://localhost:5001:polaris')).access_token;
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.auth.completeAuthentication();
        let tokenizedReq = req.clone({
            setHeaders: {
                //Authorization: `Bearer ${localStorage.getItem('access_token')}`
                Authorization: `Bearer ${JSON.parse(sessionStorage.getItem('oidc.user:http://localhost:5001:polaris')).access_token}`
               
            }
        })
        return next.handle(tokenizedReq);
    }
}