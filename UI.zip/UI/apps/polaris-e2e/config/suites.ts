
// Add alphabetically
const baseSuites = {
    all: './**/src/specs/stickynotes/*.spec.ts',
    carePlanWidget: './**/src/specs/carePlan/widget.spec.ts',
    careTeamWidget: './**/src/specs/careTeam/widget.spec.ts',
    dbscripts: './**/src/specs/database.spec.ts',
    nonStickyNotes: './**/src/specs/stickynotes/nonStickyNotes.spec.ts',
    stickyNotes: './**/src/specs/stickynotes/stickynotes.spec.ts',
    stickyApiToUiToDb: './**/api-tests/clinical/stickyApiToUiToDb.spec.ts',
    stickyToMongoDB: './**/src/specs/stickyToMongoDB.spec.ts',
    stickyUiToApi: './**/api-tests/clinical/stickyUiToApi.spec.ts',
    stickyUiToApiToDb: './**/api-tests/clinical/stickyUiToApiToDb.spec.ts',
    televisit: './**/src/specs/televisit/televisit.spec.ts',
    vitals: './**/src/specs/vitals/widget.spec.ts',
};
const suitesArray = [
    baseSuites,
];


export const suites = function () {

    function extend(obj, src) {
        for (const key in src) {
            if (src.hasOwnProperty(key)) obj[key] = src[key];
        }
        return obj;
    }

    let suitesObj = {};

    suitesArray.forEach((suite) => {
        suitesObj = extend(suitesObj, suite);
    });

    return suitesObj;
}();
