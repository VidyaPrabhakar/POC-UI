
export class DbParams {
    public parameters = {
        postgreUserName: 'postgres',
        postgrePassword: 'Emids123',
        postgreServer: 'localhost',
        postgrePort: '5432',
        postgreDatabaseName: 'polaris_clinical',
        mongoDbURL: 'mongodb://localhost:27017',
        mongoDb: 'polaris_clinical',
        mongoCollection: 'patient',
    };
}
