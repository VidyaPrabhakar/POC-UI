export class MSParams {
    public request = require('superagent');
    public parameters = {
        url: 'http://localhost:1405',
        timeout: 5000,
        apiAccessToken: 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjZkYmNiZjVlYjc4MGMzMTJhODY4NWRjNjViZjNhZjY4IiwidHlwIjoiSldUIn0.eyJuYmYiOjE1ODA4ODk2MzgsImV4cCI6MTU4MDg5MzIzOCwiaXNzIjoiaHR0cDovL2xvY2FsaG9zdDo1MDAxIiwiYXVkIjpbImh0dHA6Ly9sb2NhbGhvc3Q6NTAwMS9yZXNvdXJjZXMiLCJwb2xhcmlzX2FwaSJdLCJjbGllbnRfaWQiOiJzd2FnZ2VyLXVpIiwic3ViIjoiODg0MjExMTMiLCJhdXRoX3RpbWUiOjE1ODA4ODMxNDMsImlkcCI6ImxvY2FsIiwic2NvcGUiOlsicG9sYXJpc19hcGkiXSwiYW1yIjpbInB3ZCJdfQ.X3BQLe3iGczWCYM3fkAOtHWRhu593xQnFPBv4_yjtqxYLgVXFKNxjjaNITcLWSNPKsNivlV4CPVQy3YEhTTzwQACXQ1i7lADnNUwmcP1P0RVPid5LMqmCKlAh3GYZry-GrI97OYuh3RRgNLq0gYai9KX12wOUlr5Rb0mqCFoJxMyot6aW2xVlcPY_jSZhL0W4Rb3ATva8OeHxOgTlQj103F8sGSjqvCQz93f16475gG0TzupyZ1cNw-Lxj232qKYhcTsJH3fgnoPQsH-9LCvLQl6bQTXo3Jg7qm1DE2Nos_0DLzNCaOmyrcM4qmJ-a5fuf8a5LEajG4_xSvTcpKHQA',
    };

    public async post(url: string, body: string): Promise<string> {
        let res;
        res = await this.request.post(url).set('Authorization', `Bearer ` + this.parameters.apiAccessToken).send(body);
        return res;
    }

    public async get(url: string): Promise<string> {
        let res;
        res = await this.request.get(url).set('Authorization', `Bearer ` + this.parameters.apiAccessToken);
        return res;
    }
}
