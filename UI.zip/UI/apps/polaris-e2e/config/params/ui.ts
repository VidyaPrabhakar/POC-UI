

export class UiParams {
    public parameters = {
        url: 'http://localhost:4200',
        timeout: 5000,
    };
}
