import { element , by} from 'protractor';

export class VitalsPage  {
    public widget = {
        title: element(by.css('.vitals .title')),
        subtitle: element(by.css('.vitals .subtitle')),
        icon: element(by.css('.vitals .icon--vitals')),
        tableHeaderTitles: element.all(by.css('.vitals table tbody tr th')),
        tableHeaderSubtitles: element.all(by.css('.vitals .sub-header')),
    };
    public CONSTANTS = {
        TABLEHEADERS: ['', 'BP\nmmHg', 'HR\nbpm', 'RR\nbpm', 'Temp\n°C', 'HT\nin', 'WT\nlbs', 'BMI\nkg/m^2', 'BSA'],
    };
}
