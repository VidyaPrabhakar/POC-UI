import { element , by} from 'protractor';

export class CarePlanPage  {
    public elements = {
        aliceAron: element(by.cssContainingText('.title', 'Aaron, Alice B')),
        carePlanTitle: element(by.className('careplan-title')),
        carePlanSubTitle: element(by.className('careplan-subtitle')),
        carePlanIcon: element(by.className('icon-care-plan')),
        carePlanDescroptionsAll: element.all(by.className('careplan-desc')),
        carePlanSubDescriptionsAll: element.all(by.className('careplan-subdesc')),

    };
}
