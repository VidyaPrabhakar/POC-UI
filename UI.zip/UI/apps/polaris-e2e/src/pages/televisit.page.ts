import 'jasmine';
import { element, by } from 'protractor';

export class TeleVisitPage {
    public elements = {
        televisitNavButton: element.all(by.css('mat-sidenav-content button')).get(1),
        loginPage: {
            headerLogo: element(by.css('#navbarTogglerDemo01 a img')),
            email: element(by.css('#input25')),
            password: element(by.css('#input32')),
            signinButton: element(by.css('.o-form-button-bar input')),
            rememberMeCheckboxLabel: element(by.css('.o-form-input-name-remember label')),
            rememberMeCheckboxValue: element(by.css('.o-form-input-name-remember input')),
        },
        homePage: {
            homeTab: element(by.css('.col-10 .active')),
            welcomeNote: element.all(by.css('.col-12.col-md-5.offset-1 h2')).get(0),
            userPrev: element.all(by.css('.col-12.col-md-5.offset-1 P')).get(0),
            joinedDetails: element.all(by.css('.col-12.col-md-5.offset-1 P')).get(1),
            downloadAppButton: element.all(by.css('.home-button img')).get(0),
            startMeetingButton: element.all(by.css('.home-button img')).get(1),
            ScheduleMeetingButton: element.all(by.css('.home-button img')).get(2),
        },
        startMeeting: {
            joinViaApp: element(by.cssContainingText('a', 'Join via the app')),
            joinViaBrowser: element(by.cssContainingText('a', 'Join via the browser')),
            loginPageframe: element(by.css('#neoIframe iframe')),
            loginNameInput: element(by.css('#guest-login-button-wrap #guest-name-input')),
            joinButton: element(by.css('#guest-login-button-wrap #guest-submit-login')),
            leaveCallButton: element.all(by.className('end-video')).get(0),
            rejoinButton: element(by.css('#guest-submit-rejoin')),
            cookieMessage: element(by.css('.cc-compliance a')),
        },
    };
    public CONSTANTS = {
        UNAME: 'swatisinhabgp@gmail.com',
        PWD: 'Noaps678#',
        URL: 'https://cloud.vidyo.com/home',
    };
}

