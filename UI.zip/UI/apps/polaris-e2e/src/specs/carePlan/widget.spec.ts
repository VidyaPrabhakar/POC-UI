import { CarePlanPage, LoginPage, StickyNotePage } from '../../pages';
import { browser, ExpectedConditions } from 'protractor';


const carePlan = new CarePlanPage();
const loginPage = new LoginPage();
const stickyNotes = new StickyNotePage();

describe('Validate the Care Plan widget is displayed', async () => {
    beforeAll(async () => {
        await loginPage.login();
        await browser.sleep(2000);
        await browser.wait(ExpectedConditions.elementToBeClickable(stickyNotes.elements.selectPatient), 20000);
        await stickyNotes.elements.selectPatient.click();
        await browser.sleep(2000);
        await browser.wait(ExpectedConditions.elementToBeClickable(carePlan.elements.aliceAron), 20000);
        await carePlan.elements.aliceAron.click();
        await browser.sleep(2000);
    });
    afterAll(async () => {
        await loginPage.logout();
    });
    it('Verify if the title \'Care Plan\' is displayed', async () => {
        expect(await carePlan.elements.carePlanTitle.getText()).toBe('Care Plan');
    });
    it('Verify if the list of the goals are  displayed', async () => {
        expect(await carePlan.elements.carePlanSubTitle.isDisplayed()).toBe(true);
    });
    it('Verify if the care Plan icon is displayed', async () => {
        expect(await carePlan.elements.carePlanIcon.isDisplayed()).toBe(true);
    });
    it('Verify if the CarePlan\'s are displayed', async () => {
        expect(await carePlan.elements.carePlanDescroptionsAll.get(0).isDisplayed()).toBe(true);
    });
    it('Verify if the CarePlan\'s information is  displayed', async () => {
        expect(await carePlan.elements.carePlanSubDescriptionsAll.get(0).isDisplayed()).toBe(true);
    });
});
