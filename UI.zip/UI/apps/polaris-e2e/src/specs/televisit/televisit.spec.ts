import { } from 'jasmine';
import { LoginPage, TeleVisitPage } from '../../pages';
import { browser, ExpectedConditions } from 'protractor';
// import { Helpers } from '../../utils/Helpers';
const televisitPage = new TeleVisitPage();
const loginPage = new LoginPage();

describe('Polaris - Televisit', async () => {
  beforeAll(async () => {
    await loginPage.login();
  });
  it('validate the televisit nav button', async () => {
    await browser.wait(ExpectedConditions.elementToBeClickable(televisitPage.elements.televisitNavButton));
    expect(await televisitPage.elements.televisitNavButton.getText()).toBe('TeleVisit');
    await televisitPage.elements.televisitNavButton.click();
  });
  describe('login to Televisit Account', () => {
    describe('validate the UI elements', () => {
      beforeAll(async () => {
        //switching to the new window
        await browser.waitForAngularEnabled(false);
        await browser.sleep(2000);
        const handles = await browser.getAllWindowHandles();
        await browser.switchTo().window(handles[1]);
        await browser.sleep(2000);
        await browser.waitForAngularEnabled(true);
        //End
      });
      it('header - icon', async () => {
        expect(await televisitPage.elements.loginPage.headerLogo.isDisplayed()).toBe(true);
      });
      it('UserName input field', async () => {
        expect(await televisitPage.elements.loginPage.email.isDisplayed()).toBe(true);
      });
      it('Password input field', async () => {
        expect(await televisitPage.elements.loginPage.password.isDisplayed()).toBe(true);
      });
      it('Remember me Button', async () => {
        expect(await televisitPage.elements.loginPage.rememberMeCheckboxLabel.getText()).toBe('Remember me');
      });
      it('Sign in Button', async () => {
        expect(await televisitPage.elements.loginPage.signinButton.getAttribute('value')).toBe('Sign In');
      });
    });

    it('validate if user can login to Televisit Account', async () => {
      await browser.wait(ExpectedConditions.elementToBeClickable(televisitPage.elements.loginPage.email), 60000);
      await televisitPage.elements.loginPage.email.sendKeys(televisitPage.CONSTANTS.UNAME);
      await browser.wait(ExpectedConditions.elementToBeClickable(televisitPage.elements.loginPage.password), 60000);
      await televisitPage.elements.loginPage.password.sendKeys(televisitPage.CONSTANTS.PWD);
      if (await televisitPage.elements.startMeeting.cookieMessage.isPresent()){
        await televisitPage.elements.startMeeting.cookieMessage.click();
      }
      await browser.sleep(5000); //this wait is required
      await browser.wait(ExpectedConditions.elementToBeClickable(televisitPage.elements.loginPage.signinButton), 60000);
      await televisitPage.elements.loginPage.signinButton.click();
      await browser.wait(ExpectedConditions.elementToBeClickable(televisitPage.elements.homePage.homeTab), 60000);
      expect(await televisitPage.elements.homePage.homeTab.getText()).toBe('HOME');
    });

    describe('validate Tele Visit Home Page', () => {

      it('Home - tab', async () => {
        expect(await televisitPage.elements.homePage.homeTab.getText()).toBe('HOME');
      });

      it('Welcome label', async () => {
        expect(await televisitPage.elements.homePage.welcomeNote.getText()).toBe('Hi SWATI!');
      });

      it('Download App button', async () => {
        expect(await televisitPage.elements.homePage.downloadAppButton.getAttribute('alt')).toBe('Download App');
      });

      it('Start a meeting button', async () => {
        expect(await televisitPage.elements.homePage.startMeetingButton.getAttribute('alt')).toBe('Start a Meeting');
      });

      it('Schedule a meeting button', async () => {
        expect(await televisitPage.elements.homePage.ScheduleMeetingButton.getAttribute('alt')).toBe('Schedule a meeting');
      });
    });

    describe('validate start a meeting feature - UI Validation', () => {
      beforeAll(async () => {
        await browser.wait(ExpectedConditions.elementToBeClickable(televisitPage.elements.homePage.startMeetingButton), 30000);
        await televisitPage.elements.homePage.startMeetingButton.click();
        //switching to the new window
        await browser.waitForAngularEnabled(false);
        await browser.sleep(2000);
        const handles = await browser.getAllWindowHandles();
        console.log('handles.length = ' + handles.length);
        await browser.switchTo().window(handles[2]);
        await browser.sleep(2000);
        //await browser.waitForAngularEnabled(true);
        //End
        await browser.wait(ExpectedConditions.elementToBeClickable(televisitPage.elements.startMeeting.joinViaApp), 30000);
      });
      it('Join via app button', async () => {
        expect(await televisitPage.elements.startMeeting.joinViaApp.getText()).toBe('Join via the app');
      });

      it('Join via browser button', async () => {
        expect(await televisitPage.elements.startMeeting.joinViaBrowser.getText()).toBe('Join via the browser');
      });

      it('login name input field', async () => {
        await televisitPage.elements.startMeeting.joinViaBrowser.click();
        await browser.switchTo().frame(0),
        console.log('successflly switched to frame');
        await browser.wait(ExpectedConditions.elementToBeClickable(televisitPage.elements.startMeeting.loginNameInput), 60000);
        expect(await televisitPage.elements.startMeeting.loginNameInput.isPresent()).toBe(true);
        await televisitPage.elements.startMeeting.loginNameInput.click();
        await televisitPage.elements.startMeeting.loginNameInput.sendKeys('USER1');
      });
      it('join button', async () => {
        await browser.wait(ExpectedConditions.elementToBeClickable(televisitPage.elements.startMeeting.joinButton), 30000);
        expect(await televisitPage.elements.startMeeting.joinButton.getAttribute('value')).toBe('Join');
        await televisitPage.elements.startMeeting.joinButton.click();
      });
      it('validate if user joined the call successfully', async () => {
        await browser.sleep(20000); //this wait is required
        await browser.wait(ExpectedConditions.elementToBeClickable(televisitPage.elements.startMeeting.leaveCallButton), 60000);
        expect(await televisitPage.elements.startMeeting.leaveCallButton.isPresent()).toBe(true);
      });
      it('validate if rejoin button is displayed after leaving the call', async () => {
        await televisitPage.elements.startMeeting.leaveCallButton.click();
        await browser.wait(ExpectedConditions.elementToBeClickable(televisitPage.elements.startMeeting.rejoinButton), 30000);
        expect(await televisitPage.elements.startMeeting.rejoinButton.getAttribute('value')).toBe('Rejoin the call');
      });
    });
  });
});

