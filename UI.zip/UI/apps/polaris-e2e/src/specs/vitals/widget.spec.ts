import { LoginPage, StickyNotePage, VitalsPage, CareTeamPage } from '../../pages';
import { browser, ExpectedConditions } from 'protractor';


const vitals = new VitalsPage();
const loginPage = new LoginPage();
const stickyNotes = new StickyNotePage();
const careTeam  = new CareTeamPage();

describe('Validate the Vitals Widget', () => {
    beforeAll(async () => {
        await loginPage.login();
        await browser.wait(ExpectedConditions.elementToBeClickable(stickyNotes.elements.selectPatient), 20000);
        await stickyNotes.elements.selectPatient.click();
        await browser.sleep(2000);
        await browser.wait(ExpectedConditions.elementToBeClickable(careTeam.elements.aliceAron), 20000);
        await careTeam.elements.aliceAron.click();
        await browser.sleep(2000);
    });
    afterAll(async () => {
        await loginPage.logout();
    });
    it('Verify if \'Vitals\' Widget is displayed for patient', async () => {
        expect(await vitals.widget.title.getText()).toBe('Vitals');
    });
    it('Widget - subtitle', async () => {
        expect(await vitals.widget.subtitle.isDisplayed()).toBe(true);
    });

    it('Widget - table headers', async () => {
        expect(await vitals.widget.tableHeaderTitles.getText()).toEqual(vitals.CONSTANTS.TABLEHEADERS);
    });
});
