import 'jasmine';
import {MSParams} from '../../config/params';


const params = new MSParams();

export class CareTeamAPI {
    public async getcareTeam(patientId: string): Promise <String>
    {
        const url = params.parameters.url + `/patients/${patientId}/care-team`;
        const res = params.get(url);
        return res;

    }
}
