import 'jasmine';
import {MSParams} from '../../config/params/microservices';

const params = new MSParams();
export class VitalsGet {
    public async vitalsAPI(patientId: string): Promise<string>
    {
        const url = params.parameters.url + `/patients/${patientId}/vitals`;
        const res = params.get(url);
        return res;
    }

}