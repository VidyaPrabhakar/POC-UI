import 'jasmine';
import {MSParams} from '../../config/params';


const params = new MSParams();

export class CareplanAPI {
    public async getcarePlan(patientId: string): Promise <String>
    {
        const url = params.parameters.url + `/patients/${patientId}/care-plan`;
        const res = params.get(url);
        return res;

    }
}
