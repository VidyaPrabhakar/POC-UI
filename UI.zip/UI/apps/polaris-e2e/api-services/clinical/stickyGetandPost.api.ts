import {} from 'jasmine';
import { MSParams } from '../../config/params';

const msparams = new MSParams();
export class StickyNoteAPI {
    public async postSticky(patientId: string, body: string): Promise<string>
    {
      // const request = require('superagent');
      // process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
      const url = msparams.parameters.url + `/patients/${patientId}/sticky-notes/post`;
      const res = await msparams.post(url, body);
      return res;
    }
    public async getSticky(patientId: string): Promise<string>
    {
      // const request = require('superagent');
      // process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
      const url = msparams.parameters.url + `/patients/${patientId}/sticky-notes`;
      const res = await msparams.get(url);
      return res;
    }
}
