import 'jasmine';
import {MSParams} from '../../config/params';

const params = new MSParams();
export class AggregratorAPI{
    public async getAggregrator (patientId: string): Promise <String>
    {
        const url = params.parameters.url + `/patients/${patientId}/patient-aggregate`;
        const res = params.get(url);
        return res;
    }

}
