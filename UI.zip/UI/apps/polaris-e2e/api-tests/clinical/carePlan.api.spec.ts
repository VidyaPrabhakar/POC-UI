import 'jasmine';
import {CareplanAPI} from '../../api-services/clinical';


let response;
const carePlanGet = new CareplanAPI();
describe('validate the Get request from Care plan API', () => {
    it('Validate the response code', async () => {
        response = await carePlanGet.getcarePlan('98');
        expect(response.status).toBe(200);
    });
    it('Validate the latest record', async () => {
        expect(response.body[0].patientId).toBe(98);
    });
});

