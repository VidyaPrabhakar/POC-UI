import 'jasmine';
import { AggregratorAPI } from '../../api-services/clinical';

let res;
const aggApi = new AggregratorAPI();

describe('Validate the Get request from aggregrator API', () => {
    it('Validate the response code', async () => {
        res = await aggApi.getAggregrator('98');
        expect(res.status).toBe(200);
    });
});
