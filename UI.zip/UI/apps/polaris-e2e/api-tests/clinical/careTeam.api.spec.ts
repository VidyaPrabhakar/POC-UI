import 'jasmine';
import {CareTeamAPI} from '../../api-services/clinical';


let response;
const carePlanGet = new CareTeamAPI();
describe('validate the Get request from Care Team API', () => {
    it('Validate the response code', async () => {
        response = await carePlanGet.getcareTeam('98');
        expect(response.status).toBe(200);
    });
    it('Validate the latest record', async () => {
        expect(response.body[0].patientId).toBe(98);
    });
});

