import 'jasmine';
import {VitalsGet} from '../../api-services/clinical';

let response;
const vitalsget = new VitalsGet();


describe('Vitals GET', async () => {
    it('Validate the get status code', async () => {
        response = await vitalsget.vitalsAPI('98');
        expect(response.status).toBe(200);
    });
    it('Validate the latest record', async () => {
        expect(response.body[0].personID).toBe(98);
    });
});